import { app } from "./app";
import request from "supertest";

// BACKEND ORIENTED CANDIDATES: use your own preferred test structure
// this test is just here to give a helping hand figuring out plumbing
// rather than an endorsement or guideline on testing style
describe("/api/usage", () => {
  test("it returns 200 OK", async () => {
    const resp = await request(app).get("/api/usage");

    expect(resp.status).toBe(200);
  });
});
